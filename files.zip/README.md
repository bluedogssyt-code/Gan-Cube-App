# GAN Cube Web — Real-time 3D Rubik's Cube in Browser

A browser-only web application (React + Vite + Three.js + Web Bluetooth + cubejs) that connects to a GAN Bluetooth smart cube, reads live moves, and renders a real-time interactive 3D cube.

This project was built to run on:
- Replit
- GitHub Pages (static hosting)
- Modern Chromium browsers (Chrome, Edge)
- HTTPS only (Web Bluetooth requirement)

Repository structure (exact):
- public/index.html
- src/main.jsx
- src/App.jsx
- src/bluetooth/gan.js
- src/cube/Cube3D.jsx
- src/cube/cubeState.js
- src/styles.css
- package.json
- vite.config.js
- README.md

Important references (source / implementation guidance)
- GAN cube protocol (reverse-engineered): https://github.com/cubing/gancube
- gan-web-bluetooth example: https://github.com/afedotov/gan-web-bluetooth
- cubejs for cube state math: https://github.com/ldez/cubejs
- Three.js: https://github.com/mrdoob/three.js

What this app includes
- A visible 3D cube rendered with Three.js centered on screen
- Each cubie is a Mesh (BoxGeometry), faces colored using standard scheme
- Orbit controls enabled for camera interaction
- "Connect GAN Cube" button to trigger Web Bluetooth pairing
- Real Bluetooth code using navigator.bluetooth.requestDevice and service UUIDs
- Parsing of move notifications and conversion into standard notation (R, U, F, etc.)
- cubejs integration to track logical cube state (applyMoveToCubeJS)
- Smooth animations of physical turns on the 3D cube when moves arrive

Bluetooth notes (implemented code)
- The app uses Web Bluetooth and opens the browser pairing popup:
```js
const device = await navigator.bluetooth.requestDevice({
  filters: [{ namePrefix: "GAN" }],
  optionalServices: ["0000fff0-0000-1000-8000-00805f9b34fb"]
});
```
- The Bluetooth service UUID and the notification characteristic used are based on common GAN BLE examples:
  - Service: `0000fff0-0000-1000-8000-00805f9b34fb`
  - Characteristic (notify): `0000fff1-0000-1000-8000-00805f9b34fb`
- The code listens to characteristicvaluechanged events, parses text or binary packets, and emits moves (e.g., `"R"`, `"U'"`, `"F2"`).

3D cube & animation
- The cube is constructed from 27 Mesh objects (3x3x3).
- Each visible face gets an appropriately colored material.
- Moves are enqueued and animated smoothly using requestAnimationFrame; for each move the correct layer is rotated.
- After animation the cubies' logical coordinates are updated and their positions snapped to avoid floating point drift.

How to run locally (development)
1. Install dependencies:
   - Node >=16 recommended
   - npm install
2. Run dev server:
   - npm run dev
3. Open a modern Chromium browser to the dev URL (Vite shows it in terminal). Note: for Web Bluetooth, you must use HTTPS or localhost.

How to run on Replit
1. Create a new Replit and import this repository (GitHub -> Import).
2. Ensure Replit runs `npm run dev` (Replit auto-detects from package.json).
3. Preview the Replit app. NOTE: Replit serves over HTTPS, which allows Web Bluetooth in Chromium browsers on desktop if Replit's origin is compatible.
4. Click "Connect GAN Cube" and interact with pairing popup.

How to deploy to GitHub Pages
1. Build the static assets:
   - npm run build
2. Publish the `dist` folder to GitHub Pages:
   - Option A (manual): create a `gh-pages` branch and push the contents of `dist` to it, or use the GitHub repo's Pages settings to serve from `gh-pages` branch or `docs/` folder.
   - Option B (CI): Use GitHub Actions to build and deploy `dist` to GitHub Pages.
3. Ensure the site is served over HTTPS (GitHub Pages always serves HTTPS). Web Bluetooth works only in secure contexts.

Why HTTPS is required
- The Web Bluetooth API is restricted to secure contexts for security and privacy reasons. Browsers only allow navigator.bluetooth under HTTPS (or localhost).
- Without HTTPS the Bluetooth request will be blocked and the connection will fail.

Supported GAN cubes
- The app filters devices whose name starts with `GAN` and tries to use the common GAN BLE service/characteristic UUIDs.
- Known supported devices: GAN 356/356i/356 air series and other GAN smart cubes that expose the same BLE service/characteristics.
- If your GAN cube uses a different BLE profile, you can adapt `src/bluetooth/gan.js` to use the proper service/characteristic.

Common Bluetooth errors and troubleshooting
- "Web Bluetooth not supported in this browser":
  - Make sure you're using a Chromium-based browser (Chrome, Edge) and not Firefox or Safari.
- "RequestDevice failed" or pairing popup doesn't appear:
  - Ensure the site is served over HTTPS or localhost.
  - Ensure Bluetooth is enabled on your host machine and that the browser has location/bluetooth permissions.
- "Connection failed" or disconnected events:
  - The cube may go to sleep to save battery; try reconnecting.
  - Weak signal or interference may cause disconnects.
- If no moves appear:
  - Confirm your cube produces BLE notifications for moves (some firmware versions differ).
  - Use the `gan-web-bluetooth` example as a reference: https://github.com/afedotov/gan-web-bluetooth
  - Check console logs for raw notifications.

Development notes & implementation details
- This repository purposefully contains full Web Bluetooth code that will prompt the browser pairing UI. Do not run on insecure origins.
- The move parser in `src/bluetooth/gan.js` attempts multiple strategies (text decoding, single-byte mapping, nibble parsing) to be robust across firmware variants.
- cubejs is used for logical cube state tracking (`src/cube/cubeState.js`). Visuals are updated independently by applying rotations to the correct layer cubies.

Links
- GAN cube protocol: https://github.com/cubing/gancube
- gan-web-bluetooth example: https://github.com/afedotov/gan-web-bluetooth
- cubejs: https://github.com/ldez/cubejs
- Three.js: https://github.com/mrdoob/three.js
- Web Bluetooth docs: https://developer.mozilla.org/en-US/docs/Web/API/Web_Bluetooth_API

Notes
- All code is client-side JavaScript (no backend).
- The 3D cube is visible immediately on page load even before Bluetooth connection.
- Keep your browser console open during development to observe parsed moves and debug notifications.

License: MIT