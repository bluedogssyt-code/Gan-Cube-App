import React, {
  useRef,
  useEffect,
  useImperativeHandle,
  forwardRef,
  useState,
} from "react";
import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls";
import { getCubeNotation } from "./cubeState";

/*
  3D cube renderer using Three.js
  - Renders a 3x3x3 cube
  - Each small cubie is a Mesh (BoxGeometry)
  - Faces have colors matching Rubik's standard
  - Exposes enqueueMove(moveNotation) to animate moves: "R", "R'", "F2", etc.

  References:
  - Three.js: https://github.com/mrdoob/three.js
*/

const CUBE_SIZE = 3;
const CUBIE_SIZE = 0.95;
const GAP = 0.05;
const SPACING = CUBIE_SIZE + GAP;
const OFFSET = SPACING; // used when positioning cubies, scale factor
const FACE_COLORS = {
  U: 0xffffff, // white
  R: 0xff0000, // red
  F: 0x00a000, // green
  D: 0xffff00, // yellow
  L: 0xff8c00, // orange
  B: 0x0000ff, // blue
  default: 0x111111,
};

function createCubieMaterials(coords) {
  const [x, y, z] = coords; // coords are -1..1
  const materials = [];

  // Three.js BoxGeometry order: right, left, top, bottom, front, back
  materials.push(new THREE.MeshStandardMaterial({ color: x === 1 ? FACE_COLORS.R : 0x111111 }));
  materials.push(new THREE.MeshStandardMaterial({ color: x === -1 ? FACE_COLORS.L : 0x111111 }));
  materials.push(new THREE.MeshStandardMaterial({ color: y === 1 ? FACE_COLORS.U : 0x111111 }));
  materials.push(new THREE.MeshStandardMaterial({ color: y === -1 ? FACE_COLORS.D : 0x111111 }));
  materials.push(new THREE.MeshStandardMaterial({ color: z === 1 ? FACE_COLORS.F : 0x111111 }));
  materials.push(new THREE.MeshStandardMaterial({ color: z === -1 ? FACE_COLORS.B : 0x111111 }));

  return materials;
}

// integer rotation helpers for layer coordinate transforms
function rotateCoord(coord, axis, times) {
  // coord: [x,y,z] where each is -1,0,1
  // axis: 'x'|'y'|'z'
  // times: integer number of +90 degree rotations (can be negative)
  let [x, y, z] = coord;
  times = ((times % 4) + 4) % 4; // normalize 0..3
  for (let i = 0; i < times; i++) {
    if (axis === "x") {
      // +90 around X: (x, y, z) -> (x, -z, y)
      const ny = -z;
      const nz = y;
      y = ny;
      z = nz;
    } else if (axis === "y") {
      // +90 around Y: (x, y, z) -> (z, y, -x)
      const nx = z;
      const nz = -x;
      x = nx;
      z = nz;
    } else if (axis === "z") {
      // +90 around Z: (x, y, z) -> (-y, x, z)
      const nx = -y;
      const ny = x;
      x = nx;
      y = ny;
    }
  }
  return [x, y, z];
}

const faceConfig = {
  U: { axis: "y", index: 1, sign: 1 },
  D: { axis: "y", index: -1, sign: -1 },
  R: { axis: "x", index: 1, sign: 1 },
  L: { axis: "x", index: -1, sign: -1 },
  F: { axis: "z", index: 1, sign: 1 },
  B: { axis: "z", index: -1, sign: -1 },
};

const Cube3D = forwardRef((props, ref) => {
  const containerRef = useRef(null);
  const sceneRef = useRef(null);
  const rendererRef = useRef(null);
  const cameraRef = useRef(null);
  const controlsRef = useRef(null);
  const cubeGroupRef = useRef(null);
  const cubiesRef = useRef([]); // array of {mesh, coord: [x,y,z]}
  const queueRef = useRef([]);
  const animatingRef = useRef(false);

  useImperativeHandle(ref, () => ({
    enqueueMove(move) {
      queueRef.current.push(move);
      processQueue();
    },
  }));

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(window.devicePixelRatio || 1);
    container.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x222222);
    sceneRef.current = scene;

    // Camera
    const camera = new THREE.PerspectiveCamera(45, container.clientWidth / container.clientHeight, 0.1, 1000);
    camera.position.set(4, 4, 6);
    cameraRef.current = camera;

    // Lights
    const hemi = new THREE.HemisphereLight(0xffffff, 0x444444, 0.8);
    hemi.position.set(0, 5, 0);
    scene.add(hemi);
    const dirLight = new THREE.DirectionalLight(0xffffff, 0.6);
    dirLight.position.set(3, 10, 10);
    scene.add(dirLight);

    // Controls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.07;
    controlsRef.current = controls;

    // Root cube group
    const cubeGroup = new THREE.Group();
    scene.add(cubeGroup);
    cubeGroupRef.current = cubeGroup;

    // Create cubies (3x3x3)
    const geometry = new THREE.BoxGeometry(CUBIE_SIZE, CUBIE_SIZE, CUBIE_SIZE);
    cubiesRef.current = [];
    for (let xi = -1; xi <= 1; xi++) {
      for (let yi = -1; yi <= 1; yi++) {
        for (let zi = -1; zi <= 1; zi++) {
          // center position
          const mesh = new THREE.Mesh(geometry, createCubieMaterials([xi, yi, zi]));
          mesh.position.set(xi * SPACING, yi * SPACING, zi * SPACING);
          mesh.userData.coord = [xi, yi, zi];
          mesh.castShadow = true;
          mesh.receiveShadow = true;
          cubeGroup.add(mesh);
          cubiesRef.current.push(mesh);
        }
      }
    }

    // Ground helper (subtle)
    const grid = new THREE.GridHelper(20, 40, 0x222222, 0x111111);
    grid.rotation.x = Math.PI / 2;
    grid.position.y = -3;
    scene.add(grid);

    // Resize handler
    const onResize = () => {
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener("resize", onResize);

    // Animation loop
    let rafId;
    const animate = () => {
      rafId = requestAnimationFrame(animate);
      controls.update();
      renderer.render(scene, camera);
    };
    animate();

    // Cleanup on unmount
    return () => {
      cancelAnimationFrame(rafId);
      window.removeEventListener("resize", onResize);
      renderer.dispose();
      // remove canvas
      if (renderer.domElement && renderer.domElement.parentNode) {
        renderer.domElement.parentNode.removeChild(renderer.domElement);
      }
    };
  }, []);

  // Process queue
  function processQueue() {
    if (animatingRef.current) return;
    const next = queueRef.current.shift();
    if (!next) return;
    animatingRef.current = true;
    performMove(next).then(() => {
      animatingRef.current = false;
      // small delay then continue
      setTimeout(() => {
        processQueue();
      }, 80);
    }).catch((e) => {
      console.error("Move animation error:", e);
      animatingRef.current = false;
      processQueue();
    });
  }

  async function performMove(moveNotation) {
    // moveNotation like "R", "R'", "F2"
    const token = (moveNotation || "").trim();
    if (!token) return;
    const face = token[0].toUpperCase();
    const suffix = token.slice(1);
    const cfg = faceConfig[face];
    if (!cfg) {
      console.warn("Unknown face in move:", moveNotation);
      return;
    }
    // determine quarter turns
    let times = 1;
    if (suffix === "2") times = 2;
    else if (suffix === "'") times = 3; // three clockwise turns = one counterclockwise

    // For each quarter turn, animate 90deg rotation
    for (let t = 0; t < times; t++) {
      await animateQuarterTurn(face, cfg);
    }
  }

  function animateQuarterTurn(face, cfg) {
    return new Promise((resolve) => {
      const { axis, index } = cfg;
      const cubeGroup = cubeGroupRef.current;
      const scene = sceneRef.current;

      // Select cubies in layer (coord equals index)
      const selected = cubiesRef.current.filter(mesh => {
        const coord = mesh.userData.coord;
        if (!coord) return false;
        if (axis === "x") return coord[0] === index;
        if (axis === "y") return coord[1] === index;
        if (axis === "z") return coord[2] === index;
        return false;
      });

      if (selected.length === 0) {
        resolve();
        return;
      }

      // Create rotation group and attach selected cubies preserving world transforms
      const rotGroup = new THREE.Group();
      cubeGroup.add(rotGroup);

      selected.forEach(mesh => {
        // attach preserves world transform
        rotGroup.attach(mesh);
      });

      // Determine animation parameters
      const duration = 350; // ms
      const start = performance.now();
      const startAngle = 0;
      // angle direction: +90 around axis according to our rotation convention
      const targetAngle = Math.PI / 2;

      const axisVector = new THREE.Vector3(
        axis === "x" ? 1 : 0,
        axis === "y" ? 1 : 0,
        axis === "z" ? 1 : 0
      );

      // Animate
      function frame(now) {
        const elapsed = now - start;
        const progress = Math.min(1, elapsed / duration);
        const eased = easeInOutCubic(progress);
        const current = startAngle + (targetAngle * eased);
        // set rotation on rotGroup for the axis
        rotGroup.rotation.set(0, 0, 0);
        if (axis === "x") rotGroup.rotation.x = current;
        if (axis === "y") rotGroup.rotation.y = current;
        if (axis === "z") rotGroup.rotation.z = current;

        if (progress < 1) {
          requestAnimationFrame(frame);
        } else {
          // Snap to final state and detach cubies back to cubeGroup
          // Apply rotation to cubies' userData.coord and reposition them
          selected.forEach(mesh => {
            // compute new logical coord by rotating its old coord +90 deg around axis
            const old = mesh.userData.coord;
            let newCoord;
            if (axis === "x") newCoord = rotateCoord(old, "x", 1);
            else if (axis === "y") newCoord = rotateCoord(old, "y", 1);
            else newCoord = rotateCoord(old, "z", 1);
            mesh.userData.coord = newCoord;

            // compute new world position relative to cubeGroup
            const [nx, ny, nz] = newCoord;
            mesh.position.set(nx * SPACING, ny * SPACING, nz * SPACING);

            // Normalize rotation angles to nearest 90deg multiple to avoid float drift
            mesh.rotation.x = Math.round(mesh.rotation.x / (Math.PI / 2)) * (Math.PI / 2);
            mesh.rotation.y = Math.round(mesh.rotation.y / (Math.PI / 2)) * (Math.PI / 2);
            mesh.rotation.z = Math.round(mesh.rotation.z / (Math.PI / 2)) * (Math.PI / 2);

            // Reattach to cubeGroup preserving world transform
            cubeGroup.attach(mesh);
          });

          // remove rotGroup from scene
          if (rotGroup.parent) rotGroup.parent.remove(rotGroup);
          resolve();
        }
      }
      requestAnimationFrame(frame);
    });
  }

  function easeInOutCubic(t) {
    return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
  }

  return (
    <div
      ref={containerRef}
      style={{
        width: "100%",
        height: "640px",
        display: "block",
        margin: "0 auto",
      }}
    />
  );
});

export default Cube3D;